# Resume Classifier Web App
Upload resumes, train model, and predict roles via Streamlit.
# ======================== Imports ========================
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import re
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import SMOTE

def clean_resume(text):
    text = re.sub(r'http\S+|www\.\S+', '', text)
    text = re.sub(r'[^a-zA-Z]', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.lower().strip()

st.set_page_config(page_title="Resume Classifier", layout="wide")
st.title("📄 Resume Role Classifier App")
st.markdown("Built for project submission")

uploaded_file = st.sidebar.file_uploader("Upload Resume CSV File", type=["csv"])
model_choice = st.sidebar.selectbox("Choose Model", ["Logistic Regression", "Random Forest"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.dataframe(df.head())
    df.dropna(inplace=True)
    df['cleaned_resume'] = df['Resume_str'].apply(clean_resume)
    le = LabelEncoder()
    df['Category_encoded'] = le.fit_transform(df['Category'])
    labels = le.classes_

    tfidf = TfidfVectorizer(max_features=1500)
    X = tfidf.fit_transform(df['cleaned_resume']).toarray()
    y = df['Category_encoded']

    smote = SMOTE(random_state=42)
    X_res, y_res = smote.fit_resample(X, y)

    X_train, X_test, y_train, y_test = train_test_split(X_res, y_res, test_size=0.2)

    model = LogisticRegression(max_iter=1000) if model_choice=="Logistic Regression" else RandomForestClassifier()
    model.fit(X_train, y_train)

    input_resume = st.text_area("Paste Resume")
    if st.button("Predict"):
        cleaned = clean_resume(input_resume)
        vec = tfidf.transform([cleaned])
        pred = model.predict(vec)[0]
        st.success(le.inverse_transform([pred])[0])
else:
    st.warning("Upload a CSV file to start.")
